#include <iostream>

int main(int argc, char* argv[]) {
    std::cout << "Program started!" << std::endl;
    return 0;
}
